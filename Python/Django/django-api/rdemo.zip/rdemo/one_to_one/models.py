from django.db import models

class User(models.Model):
    user_name=models.CharField(max_length=200)
    password=models.CharField(max_length=200)

class Page(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE,primary_key=True)
    page_name=models.CharField(max_length=200)
    page_cat=models.CharField(max_length=200)
