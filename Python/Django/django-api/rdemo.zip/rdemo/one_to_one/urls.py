from django.urls import path
from .views import *

urlpatterns = [
    path('insert/',insertingdat_one_to_one,name="insertingdat_one_to_one"),
   
]