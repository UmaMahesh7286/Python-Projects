from django.shortcuts import render
from .models import *
from django.http import HttpResponse

def insertingdat_one_to_one(request):
    user=User.objects.create(user_name="Nuts",password="123")
    user.save()
    page=Page.objects.create(user=user,page_name='Java',page_cat='one')
    page.save()
    # currentuser=User.objects.get(user_name='core')
    # page=Page.objects.create(user=currentuser,page_name='java',page_cat='one')
    # page.save()
    return HttpResponse(" this is  fine ")
