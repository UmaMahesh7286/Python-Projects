from django.shortcuts import render
from .models import *
from django.http import HttpResponse

def inserManyToMany(request):
    student1 = Student.objects.create(name='John')
    student2 = Student.objects.create(name='Alice')
    
    course1 = Course.objects.create(name='Math')
    course2 = Course.objects.create(name='History')

    # Enroll students in courses
    student1.courses.add(course1, course2)
    student2.courses.add(course1)
    



    return HttpResponse("this is many to many function")

