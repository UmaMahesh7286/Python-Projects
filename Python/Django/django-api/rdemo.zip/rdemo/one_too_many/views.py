from django.shortcuts import render
from django.http import HttpResponse
from .models import *
# Create your views here.
def insert_may(request):
    # author=Author.objects.create(name='chandra')
    # author.save()
    author=Author.objects.get(name='chandra')

    book=Book.objects.create(title='kgf',author=author)
    book.save()

    return HttpResponse(" this function working fine")
