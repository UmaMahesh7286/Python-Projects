from django.apps import AppConfig


class OneTooManyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'one_too_many'
